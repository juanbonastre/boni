---
Título: "factura-ejemplo.pdf"
Carpeta: "registros/ejemplo"
boni_id: "e_01m78yg9yagqc1j8zd2h8nnf90"
boni_integrity: "user"
boni_omitted: ["archivo"]
---
