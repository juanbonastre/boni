---
Título: "foto-ejemplo.jpg"
Carpeta: "registros/ejemplo"
boni_id: "e_01m78yg9yc6n5rcbebn6mb4jtt"
boni_integrity: "user"
boni_omitted: ["archivo"]
---
