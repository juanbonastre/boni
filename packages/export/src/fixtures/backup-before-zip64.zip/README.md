# Exportación de Boni

Exportada el 2026-11-01. Son tus datos completos, en formatos abiertos: puedes abrirlos sin Boni.

- `json/<tipo>.ndjson`: la copia fiel, un elemento por línea (valores por clave de campo, texto, procedencia de
  cada valor y fechas). Boni la vuelve a importar tal cual.
- `schema.json`: cada tipo como lo guarda Boni (campos, opciones, relaciones) y un JSON Schema de sus elementos.
- `<tipo>/*.md`: una nota Markdown por elemento, con propiedades YAML (se abre en Obsidian). El texto que vino de un
  modelo o de fuera lleva las imágenes y enlaces remotos desactivados.
- `csv/<tipo>.csv`: para una hoja de cálculo (las listas, separadas por "; ").
- `views.json`: tus gráficas y atajos.

Tipos:
- Archivos (`archivos`): 2
